# Echo OS — PINN Training Codebase

Physics-Informed Neural Network for physiological state estimation
and HSAI (Health-Span Adaptability Index) prediction.

## Architecture

```
Raw sensors (ECG, PPG, BioZ, Temp, EDA, IMU)
        ↓
ODE Prior Solver (RK4, calibrated parameters)
        ↓
Residual Network (ResNet-8, 128 hidden, individual correction)
        ↓
Extended Kalman Filter (Bayesian fusion)
        ↓
Session Encoder TCN (6 layers, dilations 1-32, 256ch → 512d)
        ↓
Multi-task heads:
    ├── HSAI Head           → score 0-100 + 7 domains + confidence
    ├── Recovery Score Head → predicted delta HSAI post-session
    └── Anomaly Head        → 4-tier anomaly classification
```

**Total parameters:** ~32M

## Loss Function

```
L_total = λ_data × L_data
        + λ_physics × L_ode        (physics residual — safety-critical)
        + λ_boundary × L_boundary   (hard physiological limits, weight=10)
        + λ_smooth × L_smooth       (trajectory smoothness)
```

## Training Phases

### Phase 1: Synthetic pre-training
```bash
python training/train.py --phase pretrain --therapy cryo --epochs 100
python training/train.py --phase pretrain --therapy hbot --epochs 100
python training/train.py --phase pretrain --therapy sauna_ir --epochs 100
python training/train.py --phase pretrain --therapy run --epochs 100
```
Generates 50,000 synthetic sessions per therapy type using calibrated ODE simulator.
Must pass all literature validation targets before Phase 2.

### Phase 2: Real data fine-tuning (requires 500+ real sessions)
```bash
python training/train.py \
    --phase finetune \
    --therapy cryo \
    --checkpoint runs/pretrain_cryo/best.pt \
    --data /path/to/real_sessions/ \
    --epochs 50
```
ODE prior frozen. Only residual network + encoder + heads trained.
λ_physics increased to 0.30 to anchor to calibrated physiology.

## Literature Validation Targets

All synthetic data must reproduce these ranges (checked automatically):

| Therapy | Metric | Target | Source |
|---------|--------|--------|--------|
| Cryo (-110°C) | Post-session HRV increase | +50–100% | Louis et al. 2020 |
| Cryo (-110°C) | Peak HR increase | +8–20 bpm | Louis et al. 2020 |
| HBOT (2.4 ATA) | SpO2 stable phase | 99–100% | Clinical standard |
| HBOT (2.4 ATA) | HR decrease | -5 to -15 bpm | PMC 2025; Lund 2003 |
| Sauna (73°C) | Peak HR | 100–150 bpm | Laukkanen 2019 |

## File Structure

```
echo_pinn/
├── models/
│   ├── ode_prior.py        # Calibrated ODE models for each therapy
│   └── pinn.py             # Full PINN: residual net + TCN encoder + heads
├── training/
│   ├── loss.py             # Composite PINN loss (4 terms)
│   └── train.py            # Training loop (3 phases)
├── data/
│   └── synthetic_generator.py  # ODE-based synthetic data + noise injection
└── requirements.txt
```

## Key Design Decisions

**Why PINN over pure neural network?**
Factor-of-15 data reduction in training requirements (npj Digital Medicine 2023).
Cannot generate physiologically impossible predictions — physics constraints
are enforced at the loss level (L_ode) AND at inference via hard clamping.

**Why ResNet for residual?**
Residual connections preserve the ODE prior signal through the network.
The network learns the CORRECTION, not the trajectory from scratch.

**Why TCN for session encoder?**
TCNs outperform LSTMs on long sequences (>200 timesteps) due to parallel
computation and stable gradients. Dilated convolutions achieve receptive
field of 2^6 × 3 = 192 timesteps = 3.2 min at 1Hz, covering full cryo session.

**Why EKF for state fusion?**
Principled Bayesian fusion with uncertainty estimates. Kalman gain K = Q/(Q+R)
automatically weights ODE prediction vs observation based on learned noise levels.
Provides posterior covariance for HSAI confidence intervals.
