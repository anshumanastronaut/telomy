"""
Echo OS — PINN Loss Functions
==============================
Implements the composite PINN loss:

    L_total = λ_data × L_data + λ_physics × L_ode + λ_boundary × L_boundary + λ_smooth × L_smooth

Each term has a specific purpose:
    L_data      — supervised fit to observed sensor measurements
    L_ode       — physics residual (trajectory must satisfy calibrated ODE)
    L_boundary  — hard physiological limits (safety-critical; high weight)
    L_smooth    — trajectory smoothness (prevents overfitting to sensor noise)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass
from typing import Optional

from .ode_prior import StateIdx, PhysiologicalODEPrior, STATE_DIM


@dataclass
class LossWeights:
    """
    Lambda weights for each loss term.
    Adjusted per training phase:
        Phase 1 (synthetic pre-training): λ_physics low (ODE already drives shape)
        Phase 2 (real data fine-tuning):  λ_physics higher (anchor to calibrated physics)
    """
    data:       float = 1.00    # Supervised fit to observations
    physics:    float = 0.10    # ODE residual (increased to 0.30 in phase 2)
    boundary:   float = 10.00   # Hard physiological limits (always high)
    smooth:     float = 0.01    # Trajectory smoothness
    recovery:   float = 0.50    # Recovery score supervision (when labels available)
    anomaly:    float = 0.30    # Anomaly detection supervision (when labels available)
    hsai:       float = 0.20    # HSAI supervision (when clinical labels available)


class PINNLoss(nn.Module):
    """
    Full composite PINN loss function.

    The key innovation over standard supervised loss:
    The physics residual (L_ode) means the model cannot generate physiologically
    impossible predictions even when data signal is noisy or sparse.
    This is the core safety property of the PINN architecture.
    """

    # Hard physiological bounds for L_boundary
    BOUNDS = {
        StateIdx.HR:        (20.0,  240.0),
        StateIdx.HRV_RMSSD: (0.1,   300.0),
        StateIdx.SPO2:      (50.0,  100.0),
        StateIdx.CORE_TEMP: (33.0,   42.0),
        StateIdx.SKIN_TEMP: (-5.0,   45.0),
        StateIdx.RESP_RATE: (4.0,    60.0),
        StateIdx.BP_SYS:    (50.0,  250.0),
    }

    def __init__(
        self,
        weights: Optional[LossWeights] = None,
        ode_prior: Optional[PhysiologicalODEPrior] = None
    ):
        super().__init__()
        self.w   = weights or LossWeights()
        self.ode = ode_prior

    def forward(
        self,
        outputs: dict,              # from EchoOSPINN.forward()
        X_obs_seq: torch.Tensor,    # (batch, T, STATE_DIM) — NaN where unobserved
        U_seq: torch.Tensor,        # (batch, T, INPUT_DIM)
        theta: torch.Tensor,        # (batch, theta_dim)
        therapy_type: int,
        dt: float = 1.0,
        labels: Optional[dict] = None,  # {'recovery_delta': tensor, 'anomaly_tier': tensor, 'hsai': tensor}
        phase: str = 'pretrain'
    ) -> dict:
        """
        Compute all loss terms. Returns dict with individual terms and total.
        """
        X_fused = outputs['X_fused_seq']   # (batch, T, STATE_DIM)
        X_ode   = outputs['X_ode_seq']     # (batch, T, STATE_DIM)
        delta   = outputs['delta_seq']     # (batch, T, STATE_DIM)

        losses = {}

        # ── L_data: Supervised fit to observed sensor measurements ──────────
        # Only compute where observations exist (non-NaN)
        observed_mask = ~torch.isnan(X_obs_seq)
        if observed_mask.any():
            X_obs_filled = torch.where(observed_mask, X_obs_seq, X_fused.detach())
            # Huber loss (robust to outliers from sensor artifacts)
            l_data = F.huber_loss(
                X_fused[observed_mask],
                X_obs_filled[observed_mask],
                delta=2.0   # Huber threshold: 2 units (physiological scale)
            )
        else:
            l_data = torch.tensor(0.0, device=X_fused.device)
        losses['data'] = l_data

        # ── L_ode: Physics residual — trajectory must satisfy calibrated ODE ──
        # Compute dX/dt from the fused trajectory (finite differences)
        # Compare against ODE prediction at each step
        if self.ode is not None and self.w.physics > 0:
            l_ode = self._compute_ode_residual(
                X_fused, U_seq, theta, therapy_type, dt
            )
        else:
            l_ode = torch.tensor(0.0, device=X_fused.device)
        losses['physics'] = l_ode

        # ── L_boundary: Hard physiological limits (safety-critical) ─────────
        l_boundary = self._compute_boundary_loss(X_fused)
        losses['boundary'] = l_boundary

        # ── L_smooth: Trajectory smoothness ──────────────────────────────────
        # Penalise second derivative (d²X/dt²) — physiological signals are smooth
        if X_fused.shape[1] > 2:
            d2X = X_fused[:, 2:, :] - 2 * X_fused[:, 1:-1, :] + X_fused[:, :-2, :]
            l_smooth = (d2X ** 2).mean()
        else:
            l_smooth = torch.tensor(0.0, device=X_fused.device)
        losses['smooth'] = l_smooth

        # ── Supervised head losses (when labels available) ───────────────────
        losses['recovery'] = torch.tensor(0.0, device=X_fused.device)
        losses['anomaly']  = torch.tensor(0.0, device=X_fused.device)
        losses['hsai']     = torch.tensor(0.0, device=X_fused.device)

        if labels is not None:
            if 'recovery_delta' in labels:
                pred_recovery = outputs['recovery_score']
                true_recovery = labels['recovery_delta'].to(X_fused.device)
                losses['recovery'] = F.mse_loss(pred_recovery, true_recovery)

            if 'anomaly_tier' in labels:
                pred_anomaly = outputs['anomaly_logits']
                true_anomaly = labels['anomaly_tier'].long().to(X_fused.device)
                losses['anomaly'] = F.cross_entropy(pred_anomaly, true_anomaly)

            if 'hsai' in labels:
                pred_hsai = outputs['hsai_score']
                true_hsai = labels['hsai'].to(X_fused.device)
                losses['hsai'] = F.mse_loss(pred_hsai, true_hsai)

        # ── Phase-adjusted physics weight ────────────────────────────────────
        physics_weight = self.w.physics
        if phase == 'finetune':
            physics_weight = 0.30   # Higher in real-data fine-tuning
        elif phase == 'pretrain':
            physics_weight = 0.10

        # ── Total loss ────────────────────────────────────────────────────────
        total = (
            self.w.data      * losses['data']
          + physics_weight   * losses['physics']
          + self.w.boundary  * losses['boundary']
          + self.w.smooth    * losses['smooth']
          + self.w.recovery  * losses['recovery']
          + self.w.anomaly   * losses['anomaly']
          + self.w.hsai      * losses['hsai']
        )
        losses['total'] = total

        # Also store effective physics weight used
        losses['physics_weight_used'] = torch.tensor(physics_weight)

        return losses

    def _compute_ode_residual(
        self,
        X_fused: torch.Tensor,      # (batch, T, STATE_DIM)
        U_seq: torch.Tensor,
        theta: torch.Tensor,
        therapy_type: int,
        dt: float
    ) -> torch.Tensor:
        """
        Compute ODE residual loss at collocation points.

        For each interior timestep t:
            dX_numerical = (X[t+1] - X[t-1]) / (2*dt)   (central difference)
            dX_ode       = F(X[t], U[t], theta)
            residual     = ||dX_numerical - dX_ode||²

        This enforces that the neural correction doesn't violate the
        calibrated physiological dynamics.
        """
        T = X_fused.shape[1]
        if T < 3:
            return torch.tensor(0.0, device=X_fused.device)

        residuals = []
        # Sample at every 5th timestep (collocation points) for efficiency
        collocation_steps = range(1, T - 1, 5)

        for t in collocation_steps:
            # Numerical derivative (central difference)
            dX_numerical = (X_fused[:, t+1, :] - X_fused[:, t-1, :]) / (2.0 * dt)

            # ODE prediction at this point
            X_t = X_fused[:, t, :].detach()   # detach: ODE constrains correction, not vice versa
            U_t = U_seq[:, t, :]
            dX_ode = self.ode(X_t, U_t, theta, therapy_type)

            # Residual: penalise deviation from physics
            residual = F.mse_loss(dX_numerical, dX_ode)
            residuals.append(residual)

        return torch.stack(residuals).mean()

    def _compute_boundary_loss(self, X_fused: torch.Tensor) -> torch.Tensor:
        """
        Penalise physiological limit violations.
        Uses ReLU: penalty only when bounds are violated (one-sided).

        This is a SOFT constraint (gradient signal to push back inside bounds).
        The hard clamp in the model is the final safety backstop.
        """
        losses = []
        for state_idx, (lo, hi) in self.BOUNDS.items():
            x = X_fused[:, :, state_idx]
            # Lower bound violation
            lower_violation = F.relu(lo - x) ** 2
            # Upper bound violation
            upper_violation = F.relu(x - hi) ** 2
            losses.append(lower_violation.mean() + upper_violation.mean())

        return torch.stack(losses).mean()


# ─── Validation Metrics ───────────────────────────────────────────────────────

class ValidationMetrics:
    """
    Computes validation metrics against published literature targets.

    For each therapy type, checks whether the model's predictions
    fall within the expected physiological range from literature.
    """

    # Literature validation targets from DPR
    CRYO_TARGETS = {
        'hrv_post_increase_pct': (50.0, 100.0),    # Louis et al. 2020
        'hr_peak_increase_bpm':  (8.0, 20.0),      # Louis et al. 2020
        'skin_temp_drop_c':      (-15.0, -8.0),    # Multiple cryo studies
    }
    HBOT_TARGETS = {
        'spo2_stable_pct':       (99.0, 100.0),    # Clinical standard
        'hr_decrease_bpm':       (-15.0, -5.0),    # PMC 2025; Lund 2003
        'hrv_hf_increase_pct':   (40.0, 60.0),     # Lund 2003
    }
    SAUNA_TARGETS = {
        'hr_peak_bpm':           (100.0, 150.0),   # Laukkanen 2019
        'hr_post_decrease_bpm':  (-12.0, -5.0),    # Laukkanen 2019
        'core_temp_rise_c':      (0.3, 0.9),       # AJP-RICU 2025
    }

    @staticmethod
    def validate_cryo(X_fused: torch.Tensor, theta: torch.Tensor) -> dict:
        """Validate cryotherapy predictions against literature ranges."""
        results = {}

        # HRV increase post-session vs pre-session
        hrv_pre  = X_fused[:, 0, StateIdx.HRV_RMSSD]
        hrv_post = X_fused[:, -1, StateIdx.HRV_RMSSD]
        hrv_pct  = ((hrv_post - hrv_pre) / hrv_pre * 100).mean().item()

        lo, hi = ValidationMetrics.CRYO_TARGETS['hrv_post_increase_pct']
        results['hrv_increase_pct'] = {
            'value': hrv_pct, 'pass': lo <= hrv_pct <= hi,
            'target': f'{lo}–{hi}%', 'source': 'Louis et al. 2020'
        }

        # HR peak during session
        hr_baseline = theta[:, 0].mean().item()
        hr_peak     = X_fused[:, :, StateIdx.HR].max(dim=1).values.mean().item()
        hr_increase = hr_peak - hr_baseline

        lo, hi = ValidationMetrics.CRYO_TARGETS['hr_peak_increase_bpm']
        results['hr_peak_increase'] = {
            'value': hr_increase, 'pass': lo <= hr_increase <= hi,
            'target': f'{lo}–{hi} bpm', 'source': 'Louis et al. 2020'
        }

        # Skin temp drop
        skin_start = X_fused[:, 0, StateIdx.SKIN_TEMP].mean().item()
        skin_min   = X_fused[:, :, StateIdx.SKIN_TEMP].min(dim=1).values.mean().item()
        skin_drop  = skin_min - skin_start

        lo, hi = ValidationMetrics.CRYO_TARGETS['skin_temp_drop_c']
        results['skin_temp_drop'] = {
            'value': skin_drop, 'pass': lo <= skin_drop <= hi,
            'target': f'{lo}–{hi}°C', 'source': 'Multiple cryo studies'
        }

        results['all_pass'] = all(v['pass'] for v in results.values() if isinstance(v, dict))
        return results

    @staticmethod
    def validate_hbot(X_fused: torch.Tensor, theta: torch.Tensor) -> dict:
        results = {}

        # SpO2 during stable phase (last 50% of session)
        T = X_fused.shape[1]
        stable_spo2 = X_fused[:, T//2:, StateIdx.SPO2].mean(dim=1).mean().item()
        lo, hi = ValidationMetrics.HBOT_TARGETS['spo2_stable_pct']
        results['spo2_stable'] = {
            'value': stable_spo2, 'pass': lo <= stable_spo2 <= hi,
            'target': f'{lo}–{hi}%', 'source': 'Clinical standard'
        }

        # HR decrease
        hr_start = X_fused[:, 0, StateIdx.HR].mean().item()
        hr_stable = X_fused[:, T//2:, StateIdx.HR].mean(dim=1).mean().item()
        hr_delta = hr_stable - hr_start
        lo, hi = ValidationMetrics.HBOT_TARGETS['hr_decrease_bpm']
        results['hr_decrease'] = {
            'value': hr_delta, 'pass': lo <= hr_delta <= hi,
            'target': f'{lo}–{hi} bpm', 'source': 'PMC 2025; Lund 2003'
        }

        results['all_pass'] = all(v['pass'] for v in results.values() if isinstance(v, dict))
        return results

    @staticmethod
    def print_report(results: dict, therapy_name: str):
        print(f"\n{'='*55}")
        print(f"Validation: {therapy_name}")
        print(f"{'='*55}")
        for key, val in results.items():
            if key == 'all_pass':
                status = 'ALL PASS ✓' if val else 'SOME FAILED ✗'
                print(f"\nOverall: {status}")
            elif isinstance(val, dict):
                status = '✓ PASS' if val['pass'] else '✗ FAIL'
                print(f"  {key:30s} {val['value']:+.2f}  target={val['target']}  [{status}]")
                print(f"  {'':30s} Source: {val['source']}")
