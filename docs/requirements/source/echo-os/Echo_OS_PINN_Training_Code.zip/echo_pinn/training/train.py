"""
Echo OS — PINN Training Loop
==============================
Implements the three-phase training strategy:

    Phase 1: Synthetic pre-training
        - Train on calibrated ODE-generated synthetic data
        - λ_physics = 0.10 (ODE already drives trajectory shape)
        - Minimum 500K sessions across all therapy types
        - Must pass all literature validation targets before Phase 2

    Phase 2: Pilot fine-tuning (real data)
        - Fine-tune on real wellness centre session data
        - λ_physics = 0.30 (physics anchors prevent catastrophic forgetting)
        - Freeze ODE Prior Solver; train Residual Network + Session Encoder
        - Minimum 500 real sessions required to begin

    Phase 3: Federated learning
        - Defined in federated_trainer.py (separate module)
        - Uses FedAvg with differential privacy (ε=1.0)

Usage:
    python training/train.py --phase pretrain --therapy cryo --epochs 100
    python training/train.py --phase finetune --checkpoint run/best.pt --epochs 50
"""

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import numpy as np
import os
import json
import argparse
from pathlib import Path
from datetime import datetime
from typing import Optional

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from models.pinn import EchoOSPINN
from models.ode_prior import PhysiologicalODEPrior, TherapyType
from training.loss import PINNLoss, LossWeights, ValidationMetrics
from data.synthetic_generator import SyntheticDataGenerator, EchoSessionDataset


# ─── Config ───────────────────────────────────────────────────────────────────

class TrainingConfig:
    # Model
    STATE_DIM       = 14
    INPUT_DIM       = 7
    EMBED_DIM       = 512
    HIDDEN_DIM      = 128
    N_RES_BLOCKS    = 8
    TCN_CHANNELS    = 256
    DROPOUT         = 0.1

    # Training
    BATCH_SIZE      = 64
    LR              = 3e-4
    LR_MIN          = 1e-6
    WEIGHT_DECAY    = 1e-4
    GRAD_CLIP       = 1.0
    WARMUP_EPOCHS   = 5

    # Data
    MAX_SEQ_LEN     = 400   # seconds (max session length padded to this)
    DT              = 1.0   # time step in seconds
    VAL_FRACTION    = 0.10
    TEST_FRACTION   = 0.05

    # Synthetic data generation (Phase 1)
    PRETRAIN_SESSIONS_PER_THERAPY = 50000
    SESSION_DURATION_S = 300

    # Fine-tuning (Phase 2)
    MIN_REAL_SESSIONS = 500
    FINETUNE_LR = 1e-4

    # Checkpointing
    SAVE_EVERY_N_EPOCHS = 5
    EARLY_STOP_PATIENCE = 15


def build_model(device: str) -> EchoOSPINN:
    cfg = TrainingConfig
    return EchoOSPINN(
        state_dim=cfg.STATE_DIM, input_dim=cfg.INPUT_DIM,
        theta_dim=14, embed_dim=cfg.EMBED_DIM,
        hidden_dim=cfg.HIDDEN_DIM, n_res_blocks=cfg.N_RES_BLOCKS,
        tcn_channels=cfg.TCN_CHANNELS, dropout=cfg.DROPOUT
    ).to(device)


def build_optimizer(model: EchoOSPINN, phase: str) -> torch.optim.Optimizer:
    cfg = TrainingConfig
    lr = cfg.FINETUNE_LR if phase == 'finetune' else cfg.LR

    if phase == 'finetune':
        # Freeze ODE prior; only train residual + encoder + heads
        for param in model.ode_prior.parameters():
            param.requires_grad = False
        trainable = (
            list(model.residual.parameters())
            + list(model.encoder.parameters())
            + list(model.hsai_head.parameters())
            + list(model.recovery_head.parameters())
            + list(model.anomaly_head.parameters())
        )
        print(f"Fine-tuning mode: ODE prior frozen. Trainable params: {sum(p.numel() for p in trainable):,}")
    else:
        trainable = model.parameters()

    return torch.optim.AdamW(trainable, lr=lr, weight_decay=cfg.WEIGHT_DECAY)


def build_scheduler(optimizer, n_epochs: int, warmup_epochs: int):
    """Cosine annealing with linear warmup."""
    def lr_lambda(epoch):
        if epoch < warmup_epochs:
            return epoch / max(warmup_epochs, 1)
        progress = (epoch - warmup_epochs) / max(n_epochs - warmup_epochs, 1)
        return 0.5 * (1.0 + np.cos(np.pi * progress))

    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


# ─── Training Step ────────────────────────────────────────────────────────────

def train_step(
    model: EchoOSPINN,
    batch: dict,
    loss_fn: PINNLoss,
    optimizer: torch.optim.Optimizer,
    device: str,
    phase: str,
    grad_clip: float = 1.0
) -> dict:
    model.train()
    optimizer.zero_grad()

    X_obs   = batch['X_obs'].to(device)         # (batch, T, STATE_DIM)
    U       = batch['U'].to(device)             # (batch, T, INPUT_DIM)
    theta   = batch['theta'].to(device)         # (batch, theta_dim)
    tt      = batch['therapy_type'][0].item()   # All same in a batch
    labels  = {k: v.to(device) for k, v in batch['labels'].items()}

    outputs = model(X_obs, U, theta, therapy_type=tt, dt=TrainingConfig.DT)

    losses = loss_fn(
        outputs, X_obs, U, theta,
        therapy_type=tt, dt=TrainingConfig.DT,
        labels=labels, phase=phase
    )

    losses['total'].backward()

    # Gradient clipping (prevents exploding gradients from stiff ODEs)
    nn.utils.clip_grad_norm_(model.parameters(), grad_clip)

    optimizer.step()

    return {k: v.item() for k, v in losses.items() if isinstance(v, torch.Tensor)}


@torch.no_grad()
def validation_step(
    model: EchoOSPINN,
    batch: dict,
    loss_fn: PINNLoss,
    device: str,
    phase: str
) -> dict:
    model.eval()

    X_obs   = batch['X_obs'].to(device)
    U       = batch['U'].to(device)
    theta   = batch['theta'].to(device)
    tt      = batch['therapy_type'][0].item()
    labels  = {k: v.to(device) for k, v in batch['labels'].items()}

    outputs = model(X_obs, U, theta, therapy_type=tt, dt=TrainingConfig.DT)
    losses  = loss_fn(outputs, X_obs, U, theta, therapy_type=tt,
                      labels=labels, phase=phase)

    return {k: v.item() for k, v in losses.items() if isinstance(v, torch.Tensor)}


# ─── Full Training Run ────────────────────────────────────────────────────────

class Trainer:

    def __init__(
        self,
        phase: str = 'pretrain',
        therapy_type: int = TherapyType.CRYO,
        n_epochs: int = 100,
        device: str = 'auto',
        run_dir: str = 'runs',
        checkpoint_path: Optional[str] = None
    ):
        self.phase = phase
        self.therapy_type = therapy_type
        self.n_epochs = n_epochs
        self.device = self._resolve_device(device)
        self.run_dir = Path(run_dir) / datetime.now().strftime('%Y%m%d_%H%M%S')
        self.run_dir.mkdir(parents=True, exist_ok=True)

        print(f"\n{'='*60}")
        print(f"Echo OS PINN Trainer")
        print(f"Phase:   {phase}")
        print(f"Therapy: {therapy_type}")
        print(f"Device:  {self.device}")
        print(f"Run dir: {self.run_dir}")
        print(f"{'='*60}\n")

        # Build model
        self.model = build_model(self.device)
        print(f"Model parameters: {self.model.count_parameters():,}")

        if checkpoint_path:
            self._load_checkpoint(checkpoint_path)

        # Build loss, optimizer, scheduler
        loss_weights = LossWeights()
        self.loss_fn  = PINNLoss(loss_weights, self.model.ode_prior)
        self.optimizer = build_optimizer(self.model, phase)
        self.scheduler = build_scheduler(self.optimizer, n_epochs, TrainingConfig.WARMUP_EPOCHS)

        # Metrics tracking
        self.history = {'train': [], 'val': []}
        self.best_val_loss = float('inf')
        self.patience_counter = 0

    def _resolve_device(self, device: str) -> str:
        if device == 'auto':
            if torch.cuda.is_available():    return 'cuda'
            if torch.backends.mps.is_available(): return 'mps'
            return 'cpu'
        return device

    def prepare_data(self, real_data_path: Optional[str] = None) -> tuple:
        """Prepare train/val/test DataLoaders."""
        cfg = TrainingConfig

        if self.phase == 'pretrain':
            # Generate synthetic data
            ode_prior = PhysiologicalODEPrior().to(self.device)
            generator = SyntheticDataGenerator(ode_prior, cfg.DT, self.device)
            all_samples = generator.generate_dataset(
                n_sessions=cfg.PRETRAIN_SESSIONS_PER_THERAPY,
                therapy_type=self.therapy_type,
                session_duration_s=cfg.SESSION_DURATION_S,
                device_mode='patch'
            )
        else:
            # Load real session data
            assert real_data_path is not None, "real_data_path required for fine-tuning"
            all_samples = self._load_real_data(real_data_path)
            assert len(all_samples) >= cfg.MIN_REAL_SESSIONS, (
                f"Insufficient real data: {len(all_samples)} < {cfg.MIN_REAL_SESSIONS}"
            )
            print(f"Loaded {len(all_samples)} real sessions from {real_data_path}")

        # Split
        n = len(all_samples)
        n_test  = int(n * cfg.TEST_FRACTION)
        n_val   = int(n * cfg.VAL_FRACTION)
        n_train = n - n_val - n_test

        indices = np.random.permutation(n)
        train_s = [all_samples[i] for i in indices[:n_train]]
        val_s   = [all_samples[i] for i in indices[n_train:n_train+n_val]]
        test_s  = [all_samples[i] for i in indices[n_train+n_val:]]

        print(f"Dataset split: train={len(train_s)}, val={len(val_s)}, test={len(test_s)}")

        train_dl = DataLoader(EchoSessionDataset(train_s, cfg.MAX_SEQ_LEN),
                              batch_size=cfg.BATCH_SIZE, shuffle=True,
                              num_workers=2, pin_memory=True)
        val_dl   = DataLoader(EchoSessionDataset(val_s, cfg.MAX_SEQ_LEN),
                              batch_size=cfg.BATCH_SIZE, shuffle=False,
                              num_workers=2, pin_memory=True)
        test_dl  = DataLoader(EchoSessionDataset(test_s, cfg.MAX_SEQ_LEN),
                              batch_size=cfg.BATCH_SIZE, shuffle=False,
                              num_workers=1, pin_memory=True)

        return train_dl, val_dl, test_dl

    def train(self, train_dl, val_dl) -> dict:
        """Full training loop with early stopping."""
        cfg = TrainingConfig
        print(f"\nStarting training: {self.n_epochs} epochs\n")

        for epoch in range(self.n_epochs):
            # ── Train epoch ──
            train_losses = []
            for batch in train_dl:
                step_losses = train_step(
                    self.model, batch, self.loss_fn, self.optimizer,
                    self.device, self.phase, cfg.GRAD_CLIP
                )
                train_losses.append(step_losses)

            train_avg = self._avg_losses(train_losses)
            self.scheduler.step()

            # ── Validation epoch ──
            val_losses = []
            for batch in val_dl:
                step_losses = validation_step(
                    self.model, batch, self.loss_fn, self.device, self.phase
                )
                val_losses.append(step_losses)

            val_avg = self._avg_losses(val_losses)

            # ── Logging ──
            lr = self.scheduler.get_last_lr()[0]
            self.history['train'].append(train_avg)
            self.history['val'].append(val_avg)

            print(
                f"Epoch {epoch+1:3d}/{self.n_epochs}  "
                f"lr={lr:.2e}  "
                f"train_total={train_avg['total']:.4f}  "
                f"val_total={val_avg['total']:.4f}  "
                f"[data={val_avg['data']:.4f}  "
                f"physics={val_avg['physics']:.4f}  "
                f"boundary={val_avg['boundary']:.5f}]"
            )

            # ── Checkpointing ──
            if val_avg['total'] < self.best_val_loss:
                self.best_val_loss = val_avg['total']
                self.patience_counter = 0
                self._save_checkpoint('best.pt', epoch, val_avg)
                print(f"  → New best model saved (val_loss={self.best_val_loss:.4f})")
            else:
                self.patience_counter += 1
                if self.patience_counter >= cfg.EARLY_STOP_PATIENCE:
                    print(f"\nEarly stopping at epoch {epoch+1} (patience={cfg.EARLY_STOP_PATIENCE})")
                    break

            if (epoch + 1) % cfg.SAVE_EVERY_N_EPOCHS == 0:
                self._save_checkpoint(f'epoch_{epoch+1}.pt', epoch, val_avg)

        # Save training history
        with open(self.run_dir / 'history.json', 'w') as f:
            json.dump(self.history, f, indent=2)

        return self.history

    def run_literature_validation(self, test_dl) -> dict:
        """
        Validate model predictions against published literature ranges.
        Must pass before Phase 2 fine-tuning begins.
        """
        print("\n" + "="*60)
        print("Running literature validation...")
        print("="*60)

        self.model.eval()
        all_X_fused, all_theta = [], []

        with torch.no_grad():
            for batch in test_dl:
                X_obs = batch['X_obs'].to(self.device)
                U     = batch['U'].to(self.device)
                theta = batch['theta'].to(self.device)
                tt    = batch['therapy_type'][0].item()

                outputs = self.model(X_obs, U, theta, therapy_type=tt, dt=TrainingConfig.DT)
                all_X_fused.append(outputs['X_fused_seq'].cpu())
                all_theta.append(theta.cpu())

                if len(all_X_fused) > 10:  # Validate on first 640 sessions
                    break

        X_all = torch.cat(all_X_fused, dim=0)
        theta_all = torch.cat(all_theta, dim=0)

        if self.therapy_type == TherapyType.CRYO:
            results = ValidationMetrics.validate_cryo(X_all, theta_all)
            ValidationMetrics.print_report(results, "Cryotherapy")
        elif self.therapy_type == TherapyType.HBOT:
            results = ValidationMetrics.validate_hbot(X_all, theta_all)
            ValidationMetrics.print_report(results, "HBOT")
        else:
            results = {'all_pass': True, 'note': 'Validation not yet implemented for this therapy'}

        return results

    def _avg_losses(self, loss_list: list) -> dict:
        if not loss_list: return {}
        keys = loss_list[0].keys()
        return {k: np.mean([l[k] for l in loss_list if k in l]) for k in keys}

    def _save_checkpoint(self, filename: str, epoch: int, val_metrics: dict):
        torch.save({
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'val_metrics': val_metrics,
            'phase': self.phase,
            'therapy_type': self.therapy_type,
        }, self.run_dir / filename)

    def _load_checkpoint(self, path: str):
        print(f"Loading checkpoint: {path}")
        ckpt = torch.load(path, map_location=self.device)
        self.model.load_state_dict(ckpt['model_state_dict'])
        print(f"  Resumed from epoch {ckpt['epoch']}, phase={ckpt['phase']}")

    def _load_real_data(self, path: str) -> list:
        """
        Load real session data from Echo OS cloud export format.
        Expected format: list of JSON files, one per session.
        Each JSON contains: X_obs_seq, U_seq, theta, therapy_type, labels
        """
        import glob
        session_files = glob.glob(os.path.join(path, '*.pt'))
        samples = []
        for f in session_files:
            try:
                s = torch.load(f, map_location='cpu')
                samples.append(s)
            except Exception as e:
                print(f"Warning: Failed to load {f}: {e}")
        return samples


# ─── CLI Entry Point ──────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description='Echo OS PINN Training')
    parser.add_argument('--phase',      type=str, default='pretrain',
                        choices=['pretrain', 'finetune'])
    parser.add_argument('--therapy',    type=str, default='cryo',
                        choices=['cryo', 'hbot', 'sauna_ir', 'sauna_trad', 'run', 'hiit'])
    parser.add_argument('--epochs',     type=int, default=100)
    parser.add_argument('--device',     type=str, default='auto')
    parser.add_argument('--checkpoint', type=str, default=None)
    parser.add_argument('--data',       type=str, default=None,
                        help='Path to real session data (required for finetune)')
    parser.add_argument('--run-dir',    type=str, default='runs')
    args = parser.parse_args()

    therapy_map = {
        'cryo':      TherapyType.CRYO,
        'hbot':      TherapyType.HBOT,
        'sauna_ir':  TherapyType.SAUNA_IR,
        'sauna_trad':TherapyType.SAUNA_TRAD,
        'run':       TherapyType.RUN,
        'hiit':      TherapyType.HIIT,
    }
    therapy_type = therapy_map[args.therapy]

    trainer = Trainer(
        phase=args.phase,
        therapy_type=therapy_type,
        n_epochs=args.epochs,
        device=args.device,
        run_dir=args.run_dir,
        checkpoint_path=args.checkpoint
    )

    train_dl, val_dl, test_dl = trainer.prepare_data(
        real_data_path=args.data
    )

    history = trainer.train(train_dl, val_dl)

    # Literature validation after pre-training
    if args.phase == 'pretrain':
        val_results = trainer.run_literature_validation(test_dl)
        if not val_results.get('all_pass', False):
            print("\n⚠️  WARNING: Model failed literature validation.")
            print("   Do NOT proceed to Phase 2 fine-tuning.")
            print("   Review ODE parameters and re-run pre-training.")
        else:
            print("\n✓  All literature validation targets passed.")
            print("   Model is ready for Phase 2 fine-tuning on real data.")


if __name__ == '__main__':
    main()
