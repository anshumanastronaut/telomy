"""
Echo OS — Synthetic Data Generator
=====================================
Generates pre-training data using the calibrated ODE simulator.

Architecture:
    Layer 1: User archetype generator (5 archetypes with realistic variation)
    Layer 2: ODE-based therapy response simulator
    Layer 3: Noise & artifact injection engine
    Layer 4: Sensor emulation (converts physiological state to sensor readings)
    Layer 5: Timestamp synchroniser

Validation: Every generated batch is validated against literature ranges
before being added to the training dataset. Batches that fail validation
are rejected (not used for training).
"""

import torch
import numpy as np
from dataclasses import dataclass
from typing import Optional, Tuple, Dict
import math

from models.ode_prior import (
    PhysiologicalODEPrior, simulate_ode, clamp_physiological,
    UserTheta, TherapyType, StateIdx, InputIdx, STATE_DIM, INPUT_DIM
)


# ─── User Archetypes ──────────────────────────────────────────────────────────

ARCHETYPES = {
    'athlete': UserTheta(
        hr_baseline=52.0, hrv_baseline=85.0, sdnn_baseline=100.0,
        temp_baseline=36.5, skin_baseline=34.0, spo2_baseline=98.5,
        resp_baseline=12.0, bp_baseline=110.0,
        sns_sensitivity=0.8, pns_sensitivity=1.4,
        recovery_k=0.065, thermal_sensitivity=0.9, fitness_index=0.9,
        ab_baseline=-0.25
    ),
    'healthy_adult': UserTheta(
        hr_baseline=65.0, hrv_baseline=50.0, sdnn_baseline=60.0,
        temp_baseline=36.6, skin_baseline=33.0, spo2_baseline=97.5,
        resp_baseline=15.0, bp_baseline=118.0,
        sns_sensitivity=1.0, pns_sensitivity=1.0,
        recovery_k=0.040, thermal_sensitivity=1.0, fitness_index=0.5,
        ab_baseline=-0.1
    ),
    'sedentary': UserTheta(
        hr_baseline=75.0, hrv_baseline=28.0, sdnn_baseline=35.0,
        temp_baseline=36.7, skin_baseline=32.0, spo2_baseline=96.5,
        resp_baseline=17.0, bp_baseline=128.0,
        sns_sensitivity=1.2, pns_sensitivity=0.7,
        recovery_k=0.025, thermal_sensitivity=1.2, fitness_index=0.2,
        ab_baseline=0.15
    ),
    'metabolic_syndrome': UserTheta(
        hr_baseline=80.0, hrv_baseline=20.0, sdnn_baseline=25.0,
        temp_baseline=36.9, skin_baseline=31.5, spo2_baseline=96.0,
        resp_baseline=18.0, bp_baseline=138.0,
        sns_sensitivity=1.3, pns_sensitivity=0.6,
        recovery_k=0.018, thermal_sensitivity=1.3, fitness_index=0.15,
        ab_baseline=0.25
    ),
    'high_stress_executive': UserTheta(
        hr_baseline=72.0, hrv_baseline=22.0, sdnn_baseline=28.0,
        temp_baseline=36.7, skin_baseline=32.5, spo2_baseline=97.0,
        resp_baseline=17.0, bp_baseline=125.0,
        sns_sensitivity=1.4, pns_sensitivity=0.65,
        recovery_k=0.022, thermal_sensitivity=1.1, fitness_index=0.35,
        ab_baseline=0.20
    ),
}

ARCHETYPE_NAMES = list(ARCHETYPES.keys())


@dataclass
class SyntheticSample:
    X_obs_seq:      torch.Tensor    # (T, STATE_DIM) — with NaN for unobserved dims
    U_seq:          torch.Tensor    # (T, INPUT_DIM)
    theta:          torch.Tensor    # (theta_dim,)
    therapy_type:   int
    archetype:      str
    phase_schedule: list
    labels: dict                    # {'recovery_delta': float, 'anomaly_tier': int}


class SyntheticDataGenerator:
    """
    Generates synthetic physiological sessions for PINN pre-training.

    Usage:
        gen = SyntheticDataGenerator(ode_prior)
        dataset = gen.generate_dataset(n_sessions=50000, therapy_type=TherapyType.CRYO)
    """

    # Sensors available on each device (True = measured, False = NaN in band-only mode)
    PATCH_SENSORS = {
        StateIdx.HR: True, StateIdx.HRV_RMSSD: True, StateIdx.HRV_SDNN: True,
        StateIdx.LF_HF: True, StateIdx.SPO2: True, StateIdx.RESP_RATE: True,
        StateIdx.SKIN_TEMP: True, StateIdx.CORE_TEMP: False,
        StateIdx.BP_SYS: True, StateIdx.EDA_TONIC: False, StateIdx.EDA_PHASIC: False,
        StateIdx.PERFUSION: True, StateIdx.SNS: False, StateIdx.PNS: False
    }
    BAND_SENSORS = {
        StateIdx.HR: True, StateIdx.HRV_RMSSD: True, StateIdx.HRV_SDNN: False,
        StateIdx.LF_HF: False, StateIdx.SPO2: True, StateIdx.RESP_RATE: False,
        StateIdx.SKIN_TEMP: True, StateIdx.CORE_TEMP: False,
        StateIdx.BP_SYS: False, StateIdx.EDA_TONIC: True, StateIdx.EDA_PHASIC: True,
        StateIdx.PERFUSION: False, StateIdx.SNS: False, StateIdx.PNS: False
    }

    def __init__(
        self,
        ode_prior: PhysiologicalODEPrior,
        dt: float = 1.0,
        device: str = 'cpu'
    ):
        self.ode = ode_prior
        self.dt  = dt
        self.device = device
        self.rng = np.random.default_rng(42)

    def generate_dataset(
        self,
        n_sessions: int,
        therapy_type: int,
        session_duration_s: int = 300,   # 5 minutes default
        device_mode: str = 'patch',      # 'patch' or 'band'
        archetype_weights: Optional[Dict[str, float]] = None
    ) -> list:
        """
        Generate n_sessions synthetic sessions for a given therapy type.
        Returns list of SyntheticSample objects.
        """
        samples = []
        sensor_mask = self.PATCH_SENSORS if device_mode == 'patch' else self.BAND_SENSORS
        T = session_duration_s

        archetype_weights = archetype_weights or {k: 1.0 for k in ARCHETYPES}
        total_w = sum(archetype_weights.values())
        arch_probs = [archetype_weights[k] / total_w for k in ARCHETYPE_NAMES]

        print(f"Generating {n_sessions} synthetic {TherapyType.__dict__.get(therapy_type, 'unknown')} sessions...")

        for i in range(n_sessions):
            # Sample archetype
            arch_name = self.rng.choice(ARCHETYPE_NAMES, p=arch_probs)
            base_theta = ARCHETYPES[arch_name]

            # Add inter-individual variation (±15% on key parameters)
            theta = self._vary_theta(base_theta)

            # Generate control input sequence for this therapy
            U_seq, phase_schedule = self._generate_control_seq(
                therapy_type, T, base_theta
            )

            # Run ODE simulation
            X0 = self._initial_state(theta)
            X_true = simulate_ode(
                self.ode,
                X0.unsqueeze(0),
                U_seq.unsqueeze(0),
                theta.unsqueeze(0),
                self.dt,
                therapy_type,
                phase_schedule
            ).squeeze(0)   # (T, STATE_DIM)

            # Apply noise and artifacts
            X_noisy = self._add_noise(X_true, therapy_type)

            # Apply sensor mask (NaN for unmeasured dimensions)
            X_obs = self._apply_sensor_mask(X_noisy, sensor_mask)

            # Compute ground-truth labels
            labels = self._compute_labels(X_true, theta)

            sample = SyntheticSample(
                X_obs_seq=X_obs,
                U_seq=U_seq,
                theta=theta,
                therapy_type=therapy_type,
                archetype=arch_name,
                phase_schedule=phase_schedule,
                labels=labels
            )
            samples.append(sample)

            if (i + 1) % 5000 == 0:
                print(f"  Generated {i+1}/{n_sessions}")

        return samples

    def _vary_theta(self, base: UserTheta) -> torch.Tensor:
        """Add realistic inter-individual variation to archetype parameters."""
        t = base.to_tensor(self.device)
        noise_scale = torch.tensor([
            5.0,    # hr_baseline ±5 bpm
            10.0,   # hrv_baseline ±10 ms
            12.0,   # sdnn_baseline
            0.3,    # temp_baseline ±0.3°C
            1.5,    # skin_baseline
            0.8,    # spo2_baseline
            2.0,    # resp_baseline
            8.0,    # bp_baseline
            0.15,   # sns_sensitivity
            0.15,   # pns_sensitivity
            0.010,  # recovery_k
            0.15,   # thermal_sensitivity
            0.10,   # fitness_index
            0.05,   # ab_baseline
        ], device=self.device)

        noise = torch.randn_like(t) * noise_scale * 0.3
        return t + noise

    def _initial_state(self, theta: torch.Tensor) -> torch.Tensor:
        """Create initial state from user theta baseline values."""
        X0 = torch.zeros(STATE_DIM, device=self.device)
        X0[StateIdx.HR]         = theta[0]
        X0[StateIdx.HRV_RMSSD]  = theta[1]
        X0[StateIdx.HRV_SDNN]   = theta[2]
        X0[StateIdx.LF_HF]      = 1.5
        X0[StateIdx.SPO2]       = theta[5]
        X0[StateIdx.RESP_RATE]  = theta[6]
        X0[StateIdx.SKIN_TEMP]  = theta[4]
        X0[StateIdx.CORE_TEMP]  = theta[3]
        X0[StateIdx.BP_SYS]     = theta[7]
        X0[StateIdx.EDA_TONIC]  = 2.0 + self.rng.random() * 2.0
        X0[StateIdx.EDA_PHASIC] = 0.0
        X0[StateIdx.PERFUSION]  = 2.0
        X0[StateIdx.SNS]        = 0.3
        X0[StateIdx.PNS]        = 0.5
        return X0

    def _generate_control_seq(
        self, therapy_type: int, T: int, theta: UserTheta
    ) -> Tuple[torch.Tensor, list]:
        """Generate control input sequence and phase schedule for therapy."""
        U = torch.zeros(T, INPUT_DIM, device=self.device)
        phase_schedule = []

        if therapy_type == TherapyType.CRYO:
            # Cryo: 3-min active, then recovery
            cryo_duration = min(int(self.rng.uniform(150, 210)), T)
            ambient_temp  = float(self.rng.uniform(-170, -100))   # °C

            U[:cryo_duration, InputIdx.AMBIENT_TEMP] = ambient_temp
            U[cryo_duration:, InputIdx.AMBIENT_TEMP] = 22.0       # room temp recovery
            U[:, InputIdx.INTENSITY] = 0.8
            U[:, InputIdx.OXYGEN_FRAC] = 0.21
            U[:, InputIdx.PRESSURE_ATA] = 1.0

            phase_schedule = [(0, 'active'), (cryo_duration, 'recovery')]

        elif therapy_type == TherapyType.HBOT:
            # HBOT: 15-min compression, 60-min stable, 10-min decompression
            compress_end  = min(int(T * 0.15), T)
            stable_end    = min(int(T * 0.85), T)
            pressure      = float(self.rng.uniform(1.3, 3.0))  # ATA
            o2_frac       = float(self.rng.uniform(0.8, 1.0))  # 80-100% O2

            # Pressure ramps up during compression
            U[:compress_end, InputIdx.PRESSURE_ATA] = torch.linspace(1.0, pressure, compress_end)
            U[compress_end:stable_end, InputIdx.PRESSURE_ATA] = pressure
            U[stable_end:, InputIdx.PRESSURE_ATA] = torch.linspace(pressure, 1.0, T - stable_end)
            U[:, InputIdx.OXYGEN_FRAC] = o2_frac
            U[:, InputIdx.AMBIENT_TEMP] = 25.0

            phase_schedule = [(0, 'compression'), (compress_end, 'stable'), (stable_end, 'decompression')]

        elif therapy_type in (TherapyType.SAUNA_IR, TherapyType.SAUNA_TRAD):
            # Sauna: ramp up, active, cool-down
            if therapy_type == TherapyType.SAUNA_IR:
                target_temp = float(self.rng.uniform(45, 65))    # FIR: 45-65°C
            else:
                target_temp = float(self.rng.uniform(65, 90))    # Traditional: 65-90°C

            ramp_end = min(int(T * 0.15), T)
            cool_start = min(int(T * 0.80), T)

            U[:ramp_end, InputIdx.AMBIENT_TEMP] = torch.linspace(22.0, target_temp, ramp_end)
            U[ramp_end:cool_start, InputIdx.AMBIENT_TEMP] = target_temp
            U[cool_start:, InputIdx.AMBIENT_TEMP] = torch.linspace(target_temp, 22.0, T - cool_start)
            U[:, InputIdx.PRESSURE_ATA] = 1.0
            U[:, InputIdx.OXYGEN_FRAC] = 0.21
            U[ramp_end:cool_start, InputIdx.INTENSITY] = float(self.rng.uniform(0.5, 0.9))

            phase_schedule = [(0, 'active'), (cool_start, 'recovery')]

        elif therapy_type in (TherapyType.RUN, TherapyType.HIIT):
            intensity = float(self.rng.uniform(0.5, 0.85))
            U[:, InputIdx.INTENSITY] = intensity
            U[:, InputIdx.AMBIENT_TEMP] = float(self.rng.uniform(18, 30))
            U[:, InputIdx.PRESSURE_ATA] = 1.0
            U[:, InputIdx.OXYGEN_FRAC] = 0.21

            cool_start = int(T * 0.85)
            phase_schedule = [(0, 'active'), (cool_start, 'recovery')]

        else:
            U[:, InputIdx.AMBIENT_TEMP] = 22.0
            U[:, InputIdx.PRESSURE_ATA] = 1.0
            U[:, InputIdx.OXYGEN_FRAC] = 0.21
            phase_schedule = [(0, 'active')]

        return U, phase_schedule

    def _add_noise(self, X_true: torch.Tensor, therapy_type: int) -> torch.Tensor:
        """
        Add realistic sensor noise and artifacts.

        Noise sources:
            1. Gaussian measurement noise (sensor-specific SNR)
            2. Motion artifacts (random spikes proportional to motion)
            3. Thermal sensor lag (exponential filtering)
            4. ECG baseline wander (low-frequency drift)
            5. PPG clipping (amplitude saturation during high perfusion)
        """
        X = X_true.clone()
        T = X.shape[0]

        # 1. Gaussian noise per sensor (calibrated to realistic SNR)
        noise_std = torch.tensor([
            0.5,    # HR ±0.5 bpm (ECG/PPG derived)
            1.5,    # HRV_RMSSD ±1.5 ms
            2.0,    # HRV_SDNN ±2 ms
            0.08,   # LF/HF ±0.08
            0.3,    # SpO2 ±0.3%
            0.5,    # Resp ±0.5 br/min
            0.08,   # Skin temp ±0.08°C (TMP117: ±0.1°C spec)
            0.15,   # Core temp (derived; higher uncertainty)
            3.0,    # BP proxy (PTT-based; inherently less accurate)
            0.1,    # EDA tonic ±0.1 µS
            0.05,   # EDA phasic
            0.15,   # Perfusion index
            0.02,   # SNS (derived)
            0.02,   # PNS (derived)
        ], device=self.device)

        X += torch.randn_like(X) * noise_std.unsqueeze(0)

        # 2. Motion artifacts (sparse large spikes on HR and PPG channels)
        n_artifacts = self.rng.integers(0, 5)
        for _ in range(n_artifacts):
            t_artifact = self.rng.integers(0, T)
            duration   = self.rng.integers(2, 8)
            magnitude  = float(self.rng.uniform(5.0, 25.0))
            t_end = min(t_artifact + duration, T)
            X[t_artifact:t_end, StateIdx.HR] += magnitude * self.rng.choice([-1, 1])
            X[t_artifact:t_end, StateIdx.HRV_RMSSD] += magnitude * 0.5

        # 3. Thermal sensor lag (exponential smoothing; alpha=0.15 for TMP117)
        alpha = 0.15
        for t in range(1, T):
            X[t, StateIdx.SKIN_TEMP] = (
                alpha * X[t, StateIdx.SKIN_TEMP]
                + (1 - alpha) * X[t-1, StateIdx.SKIN_TEMP]
            )

        # 4. ECG baseline wander (low-frequency drift on HR)
        wander_freq = float(self.rng.uniform(0.05, 0.3))  # Hz
        t_arr = torch.arange(T, dtype=torch.float32, device=self.device)
        wander = torch.sin(2 * math.pi * wander_freq * t_arr / T) * 1.5
        X[:, StateIdx.HR] += wander

        # 5. Random sensor dropout (NaN for entire channel for short window)
        if self.rng.random() < 0.05:    # 5% of sessions have dropout
            dropout_ch = self.rng.choice([StateIdx.SPO2, StateIdx.EDA_TONIC])
            t_drop = self.rng.integers(0, T - 10)
            dur = self.rng.integers(5, 20)
            X[t_drop:t_drop+dur, dropout_ch] = float('nan')

        return clamp_physiological(X)

    def _apply_sensor_mask(
        self, X: torch.Tensor, sensor_mask: dict
    ) -> torch.Tensor:
        """Mask out sensors not available on the device."""
        X_obs = X.clone()
        for state_idx, available in sensor_mask.items():
            if not available:
                X_obs[:, state_idx] = float('nan')
        return X_obs

    def _compute_labels(
        self, X_true: torch.Tensor, theta: torch.Tensor
    ) -> dict:
        """
        Compute ground-truth labels from the true (noiseless) trajectory.
        These are used for supervised head training.
        """
        T = X_true.shape[0]
        hrv_baseline = theta[1].item()

        # Recovery delta: HRV at end vs HRV at start (%)
        hrv_start = X_true[0, StateIdx.HRV_RMSSD].item()
        hrv_end   = X_true[-1, StateIdx.HRV_RMSSD].item()
        recovery_delta = (hrv_end - hrv_start) / max(hrv_baseline, 1.0) * 100.0

        # Simple HSAI proxy label (for pre-training; real labels from clinical data later)
        # Based on HRV percentile relative to archetype baseline
        hrv_mean = X_true[:, StateIdx.HRV_RMSSD].mean().item()
        hrv_ratio = min(hrv_mean / max(hrv_baseline, 1.0), 2.0)
        hsai_proxy = min(100.0, max(0.0, hrv_ratio * 60.0))

        # Anomaly tier: 0=normal (most synthetic data; inject rare anomalies)
        anomaly_tier = 0
        hr_max = X_true[:, StateIdx.HR].max().item()
        spo2_min = X_true[:, StateIdx.SPO2].min().item()
        if hr_max > 200 or spo2_min < 90:
            anomaly_tier = 3  # Tier 3: acute
        elif hr_max > 180 or spo2_min < 94:
            anomaly_tier = 2  # Tier 2: watch

        return {
            'recovery_delta': torch.tensor(recovery_delta, dtype=torch.float32),
            'anomaly_tier':   torch.tensor(anomaly_tier, dtype=torch.long),
            'hsai':           torch.tensor(hsai_proxy, dtype=torch.float32),
        }


# ─── PyTorch Dataset ──────────────────────────────────────────────────────────

class EchoSessionDataset(torch.utils.data.Dataset):
    """
    PyTorch Dataset wrapping a list of SyntheticSample objects.
    Handles variable-length sessions by padding to max_len.
    """

    def __init__(self, samples: list, max_len: int = 400):
        self.samples = samples
        self.max_len = max_len

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> dict:
        s = self.samples[idx]
        T = s.X_obs_seq.shape[0]
        pad = self.max_len - T

        # Pad sequences to max_len with NaN (will be masked in loss)
        if pad > 0:
            nan_pad_X = torch.full((pad, STATE_DIM), float('nan'))
            X_padded = torch.cat([s.X_obs_seq, nan_pad_X], dim=0)
            zero_pad_U = torch.zeros(pad, INPUT_DIM)
            U_padded = torch.cat([s.U_seq, zero_pad_U], dim=0)
        else:
            X_padded = s.X_obs_seq[:self.max_len]
            U_padded = s.U_seq[:self.max_len]

        return {
            'X_obs':        X_padded,           # (max_len, STATE_DIM)
            'U':            U_padded,            # (max_len, INPUT_DIM)
            'theta':        s.theta,             # (theta_dim,)
            'therapy_type': torch.tensor(s.therapy_type),
            'seq_len':      torch.tensor(T),
            'labels':       {k: v for k, v in s.labels.items()},
        }
