"""
Echo OS — PINN Residual Network + Session Encoder + Full PINN Model
====================================================================
Architecture:
    1. PhysiologicalODEPrior  → X_ode(t): physics-based prediction
    2. ResidualNetwork        → ΔX(t): individual deviation correction
    3. Extended Kalman Filter → X_fused(t): Bayesian state fusion
    4. SessionEncoderTCN      → e ∈ R^512: session embedding
    5. PredictionHeads        → HSAI, recovery score, anomaly flag

Total trainable parameters: ~32M
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple
import math

from .ode_prior import (
    PhysiologicalODEPrior, simulate_ode,
    STATE_DIM, INPUT_DIM, UserTheta, clamp_physiological
)


# ─── Residual Network ─────────────────────────────────────────────────────────

class ResidualBlock(nn.Module):
    """Standard pre-activation residual block for time-series."""

    def __init__(self, dim: int, dropout: float = 0.1):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.norm2 = nn.LayerNorm(dim)
        self.ff1   = nn.Linear(dim, dim * 2)
        self.ff2   = nn.Linear(dim * 2, dim)
        self.drop  = nn.Dropout(dropout)
        self.act   = nn.GELU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        x = self.norm1(x)
        x = self.act(self.ff1(x))
        x = self.drop(x)
        x = self.ff2(x)
        x = self.norm2(x + residual)
        return x


class ResidualNetwork(nn.Module):
    """
    Neural residual correction network.

    Learns the individual-specific deviation from the ODE prior:
        ΔX(t) = X_real(t) - X_ode(t)

    Architecture: 8 residual blocks, 128 hidden units, GELU activation.
    Input: [X_ode(t) || observed_sensors(t) || U(t) || user_embedding]
    Output: ΔX(t) correction vector (STATE_DIM)

    ~1.2M parameters.
    """

    def __init__(
        self,
        state_dim: int = STATE_DIM,
        input_dim: int = INPUT_DIM,
        theta_dim: int = 14,
        hidden_dim: int = 128,
        n_blocks: int = 8,
        dropout: float = 0.1
    ):
        super().__init__()
        # Input: [X_ode | X_observed | U | theta] where X_observed may be partial
        # (NaN-masked for unobserved dimensions)
        in_dim = state_dim * 2 + input_dim + theta_dim

        self.input_proj = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.GELU(),
            nn.LayerNorm(hidden_dim)
        )
        self.blocks = nn.ModuleList([
            ResidualBlock(hidden_dim, dropout) for _ in range(n_blocks)
        ])
        self.output_proj = nn.Linear(hidden_dim, state_dim)

        # Initialise output to near-zero (residual starts small)
        nn.init.normal_(self.output_proj.weight, std=0.01)
        nn.init.zeros_(self.output_proj.bias)

    def forward(
        self,
        X_ode: torch.Tensor,        # (batch, STATE_DIM)
        X_obs: torch.Tensor,        # (batch, STATE_DIM) — NaN where not observed
        U: torch.Tensor,            # (batch, INPUT_DIM)
        theta: torch.Tensor,        # (batch, theta_dim)
    ) -> torch.Tensor:
        """Returns ΔX residual correction (batch, STATE_DIM)."""
        # Replace NaN observations with ODE prediction (graceful degradation)
        X_obs_filled = torch.where(torch.isnan(X_obs), X_ode.detach(), X_obs)

        x = torch.cat([X_ode, X_obs_filled, U, theta], dim=-1)
        x = self.input_proj(x)
        for block in self.blocks:
            x = block(x)
        delta = self.output_proj(x)

        # Constrain residual magnitude (prevents residual from dominating physics)
        delta = torch.tanh(delta) * 5.0   # max ±5 units per state dimension
        return delta


# ─── TCN Session Encoder ─────────────────────────────────────────────────────

class TemporalBlock(nn.Module):
    """Dilated causal convolution block for TCN."""

    def __init__(self, in_ch: int, out_ch: int, kernel: int, dilation: int, dropout: float):
        super().__init__()
        padding = (kernel - 1) * dilation
        self.conv1 = nn.utils.weight_norm(
            nn.Conv1d(in_ch, out_ch, kernel, dilation=dilation, padding=padding)
        )
        self.conv2 = nn.utils.weight_norm(
            nn.Conv1d(out_ch, out_ch, kernel, dilation=dilation, padding=padding)
        )
        self.relu  = nn.ReLU()
        self.drop  = nn.Dropout(dropout)
        self.net   = nn.Sequential(self.conv1, self.relu, self.drop,
                                   self.conv2, self.relu, self.drop)
        self.downsample = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else None
        self.padding = padding

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Causal: remove future leak by trimming right padding
        out = self.net(x)
        out = out[:, :, :-self.padding] if self.padding > 0 else out
        res = x if self.downsample is None else self.downsample(x)
        # Align lengths
        if out.shape[-1] != res.shape[-1]:
            res = res[:, :, :out.shape[-1]]
        return self.relu(out + res)


class SessionEncoderTCN(nn.Module):
    """
    Temporal Convolutional Network session encoder.

    Input:  fused physiological state time series (batch, T, STATE_DIM)
    Output: session embedding vector e ∈ R^512

    Architecture:
        6 TCN layers, kernel=3, dilations=[1,2,4,8,16,32]
        256 channels → adaptive average pool → 512-dim projection

    ~4.8M parameters.
    """

    def __init__(
        self,
        state_dim: int = STATE_DIM,
        embed_dim: int = 512,
        n_channels: int = 256,
        kernel_size: int = 3,
        dropout: float = 0.1
    ):
        super().__init__()
        dilations = [1, 2, 4, 8, 16, 32]
        channels  = [state_dim] + [n_channels] * len(dilations)

        self.tcn_blocks = nn.ModuleList([
            TemporalBlock(channels[i], channels[i+1], kernel_size, dilations[i], dropout)
            for i in range(len(dilations))
        ])
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.proj = nn.Sequential(
            nn.Linear(n_channels, embed_dim),
            nn.GELU(),
            nn.LayerNorm(embed_dim)
        )

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        """
        X: (batch, T, state_dim)
        Returns: (batch, embed_dim)
        """
        x = X.permute(0, 2, 1)   # (batch, state_dim, T) for Conv1d
        for block in self.tcn_blocks:
            x = block(x)
        x = self.pool(x).squeeze(-1)   # (batch, n_channels)
        return self.proj(x)


# ─── Prediction Heads ─────────────────────────────────────────────────────────

class HSAIHead(nn.Module):
    """
    Computes HSAI score and 7 domain scores from session embedding.
    Also outputs confidence (uncertainty estimate as predicted variance).

    Output: (hsai_score, domain_scores_7, confidence)
    """

    DOMAIN_WEIGHTS = torch.tensor([0.25, 0.20, 0.15, 0.13, 0.12, 0.10, 0.05])

    def __init__(self, embed_dim: int = 512, dropout: float = 0.1):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, 256), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(256, 128),       nn.GELU(), nn.Dropout(dropout),
        )
        self.domain_head     = nn.Linear(128, 7)    # 7 domain scores
        self.confidence_head = nn.Linear(128, 7)    # predicted variance per domain

    def forward(self, embedding: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Returns:
            hsai_score  (batch,)       — weighted composite 0–100
            domain_scores (batch, 7)   — individual domain scores 0–100
            confidence  (batch,)       — ±2σ uncertainty estimate
        """
        h = self.mlp(embedding)
        raw_domains = self.domain_head(h)
        log_var     = self.confidence_head(h)

        # Sigmoid to [0, 100]
        domain_scores = torch.sigmoid(raw_domains) * 100.0

        # Weighted composite HSAI
        weights = self.DOMAIN_WEIGHTS.to(embedding.device)
        hsai_score = (domain_scores * weights).sum(dim=-1)

        # Confidence: mean predicted std across domains
        domain_std = torch.exp(0.5 * log_var)   # (batch, 7)
        confidence = domain_std.mean(dim=-1) * 2.0  # 2σ interval

        return hsai_score, domain_scores, confidence


class RecoveryScoreHead(nn.Module):
    """Predicts delta HSAI within 24h of session (session effectiveness score)."""

    def __init__(self, embed_dim: int = 512):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, 128), nn.GELU(),
            nn.Linear(128, 64),        nn.GELU(),
            nn.Linear(64, 1)
        )

    def forward(self, embedding: torch.Tensor) -> torch.Tensor:
        """Returns predicted HSAI delta (batch,) — positive means improvement."""
        return self.mlp(embedding).squeeze(-1)


class AnomalyHead(nn.Module):
    """
    Detects anomalous physiological states.
    3-tier output: (0=normal, 1=tier1_soft, 2=tier2_watch, 3=tier3_acute)
    """

    def __init__(self, embed_dim: int = 512):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, 128), nn.GELU(),
            nn.Linear(128, 4)   # 4-class logits
        )

    def forward(self, embedding: torch.Tensor) -> torch.Tensor:
        """Returns logits (batch, 4) — use softmax for probabilities."""
        return self.mlp(embedding)


# ─── Full PINN Model ──────────────────────────────────────────────────────────

class EchoOSPINN(nn.Module):
    """
    Full Echo OS Physics-Informed Neural Network.

    Combines:
        1. Calibrated ODE prior (therapy-specific physiology)
        2. Neural residual correction (individual-specific deviations)
        3. TCN session encoder (temporal compression)
        4. Multi-task prediction heads (HSAI, recovery, anomaly)

    The model is trained with a composite loss:
        L = λ_data × L_data + λ_physics × L_ode + λ_boundary × L_boundary + λ_smooth × L_smooth

    Usage:
        model = EchoOSPINN()
        outputs = model(X_obs_seq, U_seq, theta, therapy_type, dt)
    """

    def __init__(
        self,
        state_dim: int       = STATE_DIM,
        input_dim: int       = INPUT_DIM,
        theta_dim: int       = 14,
        embed_dim: int       = 512,
        hidden_dim: int      = 128,
        n_res_blocks: int    = 8,
        tcn_channels: int    = 256,
        dropout: float       = 0.1
    ):
        super().__init__()

        # Physics prior
        self.ode_prior  = PhysiologicalODEPrior()

        # Neural residual correction
        self.residual   = ResidualNetwork(
            state_dim, input_dim, theta_dim, hidden_dim, n_res_blocks, dropout
        )

        # Session encoder
        self.encoder    = SessionEncoderTCN(
            state_dim, embed_dim, tcn_channels, dropout=dropout
        )

        # Prediction heads
        self.hsai_head      = HSAIHead(embed_dim, dropout)
        self.recovery_head  = RecoveryScoreHead(embed_dim)
        self.anomaly_head   = AnomalyHead(embed_dim)

        # Learnable noise covariance for EKF (log-parameterised, always positive)
        self.log_Q_diag = nn.Parameter(torch.zeros(state_dim))  # process noise
        self.log_R_diag = nn.Parameter(torch.zeros(state_dim))  # measurement noise

    @property
    def Q_diag(self) -> torch.Tensor:
        return torch.exp(self.log_Q_diag) + 1e-6

    @property
    def R_diag(self) -> torch.Tensor:
        return torch.exp(self.log_R_diag) + 1e-6

    def forward(
        self,
        X_obs_seq: torch.Tensor,    # (batch, T, STATE_DIM) — NaN where unobserved
        U_seq: torch.Tensor,        # (batch, T, INPUT_DIM)
        theta: torch.Tensor,        # (batch, theta_dim)
        therapy_type: int,
        dt: float = 1.0,            # time step in seconds
        phase_schedule: Optional[list] = None,
        return_trajectory: bool = True
    ) -> dict:
        """
        Forward pass through full PINN.

        Returns dict with:
            X_fused_seq     (batch, T, STATE_DIM) — fused physiological trajectory
            X_ode_seq       (batch, T, STATE_DIM) — ODE prior trajectory
            delta_seq       (batch, T, STATE_DIM) — residual corrections
            session_embed   (batch, embed_dim)    — session embedding
            hsai_score      (batch,)
            domain_scores   (batch, 7)
            hsai_confidence (batch,)
            recovery_score  (batch,)
            anomaly_logits  (batch, 4)
        """
        batch, T, _ = X_obs_seq.shape

        # ── Step 1: ODE trajectory ──
        X0_ode = X_obs_seq[:, 0, :].clone()
        # Fill NaN in initial state with population means
        X0_ode = torch.where(torch.isnan(X0_ode), self._population_mean(X0_ode), X0_ode)

        X_ode_seq = simulate_ode(
            self.ode_prior, X0_ode, U_seq, theta, dt, therapy_type, phase_schedule
        )  # (batch, T, STATE_DIM)

        # ── Step 2: Residual correction at each timestep ──
        delta_list = []
        X_fused_list = []

        for t in range(T):
            X_ode_t = X_ode_seq[:, t, :]
            X_obs_t = X_obs_seq[:, t, :]
            U_t     = U_seq[:, t, :]

            delta_t = self.residual(X_ode_t, X_obs_t, U_t, theta)
            X_pred_t = X_ode_t + delta_t

            # ── Step 3: Simple Kalman fusion (linearised EKF step) ──
            # Innovation = observed - predicted (where observed)
            observed_mask = ~torch.isnan(X_obs_t)
            innovation = torch.where(observed_mask, X_obs_t - X_pred_t, torch.zeros_like(X_pred_t))

            # Kalman gain K = Q / (Q + R) per dimension (diagonal approximation)
            Q = self.Q_diag.unsqueeze(0)
            R = self.R_diag.unsqueeze(0)
            K = Q / (Q + R)  # (1, STATE_DIM)
            K = K * observed_mask.float()  # Only update where observed

            X_fused_t = X_pred_t + K * innovation
            X_fused_t = clamp_physiological(X_fused_t)

            delta_list.append(delta_t.unsqueeze(1))
            X_fused_list.append(X_fused_t.unsqueeze(1))

        delta_seq   = torch.cat(delta_list, dim=1)    # (batch, T, STATE_DIM)
        X_fused_seq = torch.cat(X_fused_list, dim=1)  # (batch, T, STATE_DIM)

        # ── Step 4: Session encoding ──
        session_embed = self.encoder(X_fused_seq)   # (batch, embed_dim)

        # ── Step 5: Prediction heads ──
        hsai_score, domain_scores, hsai_confidence = self.hsai_head(session_embed)
        recovery_score  = self.recovery_head(session_embed)
        anomaly_logits  = self.anomaly_head(session_embed)

        return {
            'X_fused_seq':      X_fused_seq,
            'X_ode_seq':        X_ode_seq,
            'delta_seq':        delta_seq,
            'session_embed':    session_embed,
            'hsai_score':       hsai_score,
            'domain_scores':    domain_scores,
            'hsai_confidence':  hsai_confidence,
            'recovery_score':   recovery_score,
            'anomaly_logits':   anomaly_logits,
        }

    def _population_mean(self, X: torch.Tensor) -> torch.Tensor:
        """Population mean physiological state for NaN imputation."""
        means = torch.tensor([
            65.0,   # HR
            45.0,   # HRV_RMSSD
            55.0,   # HRV_SDNN
            1.5,    # LF/HF
            97.5,   # SpO2
            15.0,   # Resp rate
            33.0,   # Skin temp
            36.6,   # Core temp
            118.0,  # BP systolic
            2.0,    # EDA tonic
            0.0,    # EDA phasic
            2.0,    # Perfusion
            0.3,    # SNS
            0.5,    # PNS
        ], device=X.device)
        return means.unsqueeze(0).expand_as(X)

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)
