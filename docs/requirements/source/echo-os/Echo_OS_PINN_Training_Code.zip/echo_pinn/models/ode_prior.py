"""
Echo OS — Physiological ODE Prior
==================================
Calibrated differential equation models for each therapy type.
Parameters sourced from peer-reviewed literature (cited inline).

Each therapy model implements:
    dX/dt = F(X, U, theta)

Where:
    X = physiological state vector (14-dim)
    U = therapy control input vector
    theta = user-specific parameters (personalised per user)

Literature sources:
    - Louis et al. (2020, Eur J Appl Physiol): cryotherapy HRV parameters
    - Laukkanen et al. (2019, ScienceDirect): sauna cardiovascular response
    - StatPearls HBOT (2025): hyperbaric oxygen physiology
    - PMC (2025): HBOT HR decrease 7.23% over 60 min
    - AJP-RICU (2025): FIR sauna thermoregulatory response
"""

import torch
import torch.nn as nn
from dataclasses import dataclass
from typing import Optional
import math


# ─── State Vector Index Constants ────────────────────────────────────────────
class StateIdx:
    HR          = 0   # Heart rate (bpm)
    HRV_RMSSD   = 1   # HRV RMSSD (ms)
    HRV_SDNN    = 2   # HRV SDNN (ms)
    LF_HF       = 3   # LF/HF ratio (dimensionless)
    SPO2        = 4   # SpO2 (%)
    RESP_RATE   = 5   # Respiratory rate (breaths/min)
    SKIN_TEMP   = 6   # Skin temperature (°C)
    CORE_TEMP   = 7   # Core temperature (°C, estimated)
    BP_SYS      = 8   # Systolic BP proxy (mmHg)
    EDA_TONIC   = 9   # Tonic EDA (µS)
    EDA_PHASIC  = 10  # Phasic EDA delta (µS)
    PERFUSION   = 11  # Perfusion index (%)
    SNS         = 12  # Sympathetic nervous system activation (0–1)
    PNS         = 13  # Parasympathetic nervous system activation (0–1)

STATE_DIM = 14


# ─── Control Input Index Constants ───────────────────────────────────────────
class InputIdx:
    THERAPY_TYPE    = 0   # One-hot encoded (see TherapyType)
    INTENSITY       = 1   # Normalised intensity 0–1
    DURATION_FRAC   = 2   # Fraction of session elapsed (0–1)
    AMBIENT_TEMP    = 3   # Chamber/ambient temperature (°C)
    OXYGEN_FRAC     = 4   # Oxygen fraction (0–1; 0.21 = air, 1.0 = pure O2)
    PRESSURE_ATA    = 5   # Pressure in ATA (1.0 = sea level)
    IRRADIANCE      = 6   # Light irradiance mW/cm² (0 if not light therapy)

INPUT_DIM = 7


class TherapyType:
    CRYO        = 0
    HBOT        = 1
    SAUNA_IR    = 2
    SAUNA_TRAD  = 3
    COLD_PLUNGE = 4
    RED_LIGHT   = 5
    RUN         = 6
    HIIT        = 7
    LIFT        = 8
    MEDITATION  = 9
    REST        = 10
    OTHER       = 11


@dataclass
class UserTheta:
    """
    User-specific ODE parameters (theta).
    Initialised from population priors; updated via Bayesian inference
    after each session. All values stored as tensors for gradient flow.
    """
    # Baseline physiological state
    hr_baseline:    float = 65.0    # bpm
    hrv_baseline:   float = 45.0    # ms RMSSD
    sdnn_baseline:  float = 55.0    # ms
    temp_baseline:  float = 36.6    # °C core
    skin_baseline:  float = 33.0    # °C skin
    spo2_baseline:  float = 97.5    # %
    resp_baseline:  float = 15.0    # breaths/min
    bp_baseline:    float = 118.0   # mmHg systolic

    # Autonomic sensitivity (population: 1.0; athlete: 1.3; sedentary: 0.7)
    sns_sensitivity:    float = 1.0
    pns_sensitivity:    float = 1.0

    # Recovery constant k (HRV recovery; units: 1/min)
    # Literature: Louis et al. 2020 — HRV returns to baseline ~15-20 min post-cryo
    # k = ln(2) / half_life → k = 0.693 / 17.5 min ≈ 0.040/min
    recovery_k:     float = 0.040

    # Thermal sensitivity (affects cryo/sauna response amplitude)
    thermal_sensitivity: float = 1.0

    # Fitness index (0=sedentary, 1=elite; affects HR response magnitude)
    fitness_index:  float = 0.5

    # Autonomic balance baseline (SNS - PNS; negative = parasympathetic dominant)
    ab_baseline:    float = -0.1

    def to_tensor(self, device='cpu') -> torch.Tensor:
        """Flatten to parameter vector for PINN conditioning."""
        vals = [
            self.hr_baseline, self.hrv_baseline, self.sdnn_baseline,
            self.temp_baseline, self.skin_baseline, self.spo2_baseline,
            self.resp_baseline, self.bp_baseline,
            self.sns_sensitivity, self.pns_sensitivity,
            self.recovery_k, self.thermal_sensitivity,
            self.fitness_index, self.ab_baseline
        ]
        return torch.tensor(vals, dtype=torch.float32, device=device)

    @property
    def dim(self) -> int:
        return 14


# ─── ODE Models Per Therapy ───────────────────────────────────────────────────

class CryotherapyODE(nn.Module):
    """
    Whole-body cryotherapy ODE model.

    Calibrated parameters:
        alpha1 = 0.10 bpm/(°C·s): HR increase per unit cold stimulus
            Source: Louis et al. 2020 — ~10-15 bpm increase in first 30s at ΔT ~130°C
        beta3  = 0.06 /min: HRV rebound rate post-session
            Source: Louis et al. 2020 — RMSSD ~52ms at 20min post from ~28ms baseline
        k1     = 0.010 /s: skin cooling Newton coefficient at -110°C
            Source: Calibrated from cryo skin temp trajectory literature
    """

    def __init__(self):
        super().__init__()
        # Learnable parameters initialised from literature; constrained positive
        self.log_alpha1 = nn.Parameter(torch.tensor(math.log(0.10)))  # HR gain
        self.log_alpha2 = nn.Parameter(torch.tensor(math.log(0.20)))  # HRV suppression
        self.log_beta1  = nn.Parameter(torch.tensor(math.log(0.04)))  # PNS brake on HR
        self.log_beta3  = nn.Parameter(torch.tensor(math.log(0.06)))  # HRV rebound
        self.log_gamma1 = nn.Parameter(torch.tensor(math.log(0.07)))  # HR mean reversion
        self.log_k1     = nn.Parameter(torch.tensor(math.log(0.010))) # skin cooling

    @property
    def alpha1(self): return torch.exp(self.log_alpha1)
    @property
    def alpha2(self): return torch.exp(self.log_alpha2)
    @property
    def beta1(self):  return torch.exp(self.log_beta1)
    @property
    def beta3(self):  return torch.exp(self.log_beta3)
    @property
    def gamma1(self): return torch.exp(self.log_gamma1)
    @property
    def k1(self):     return torch.exp(self.log_k1)

    def forward(
        self,
        X: torch.Tensor,        # (batch, STATE_DIM)
        U: torch.Tensor,        # (batch, INPUT_DIM)
        theta: torch.Tensor,    # (batch, theta_dim)
        phase: str = 'active'   # 'active' or 'recovery'
    ) -> torch.Tensor:
        """Returns dX/dt for cryotherapy."""
        dX = torch.zeros_like(X)

        # Unpack state
        HR          = X[:, StateIdx.HR]
        HRV         = X[:, StateIdx.HRV_RMSSD]
        SKIN        = X[:, StateIdx.SKIN_TEMP]
        SNS         = X[:, StateIdx.SNS]
        PNS         = X[:, StateIdx.PNS]

        # Unpack theta baselines
        hr_base     = theta[:, 0]
        hrv_base    = theta[:, 1]
        skin_base   = theta[:, 4]
        sns_sens    = theta[:, 8]
        k_recovery  = theta[:, 10]
        thermal_s   = theta[:, 11]

        # Ambient temperature from control input
        ambient     = U[:, InputIdx.AMBIENT_TEMP]   # e.g. -110°C

        # Cold stimulus intensity: normalised temperature differential
        # S_cold = |ambient - skin| / scaling_factor
        S_cold = torch.abs(ambient - SKIN) / 100.0 * thermal_s

        if phase == 'active':
            # HR: sympathetic spike during cold exposure
            # dHR/dt = alpha1*S_cold*sns_sens - beta1*PNS - gamma1*(HR - hr_base)
            dX[:, StateIdx.HR] = (
                self.alpha1 * S_cold * sns_sens
                - self.beta1 * PNS
                - self.gamma1 * (HR - hr_base)
            )

            # HRV: suppressed during cold (sympathetic dominance)
            # dHRV/dt = -alpha2*S_cold - noise_term
            dX[:, StateIdx.HRV_RMSSD] = -self.alpha2 * S_cold

            # SNS activation
            dX[:, StateIdx.SNS] = self.alpha1 * S_cold * 0.5 - 0.02 * SNS

            # PNS suppression
            dX[:, StateIdx.PNS] = -self.alpha1 * S_cold * 0.3

            # Skin temperature: Newton cooling toward ambient
            # dT_skin/dt = -k1 * (skin - ambient)
            dX[:, StateIdx.SKIN_TEMP] = -self.k1 * (SKIN - ambient)

            # BP: transient increase during cold (vasoconstriction)
            dX[:, StateIdx.BP_SYS] = self.alpha1 * S_cold * 2.0

            # Respiration: increases with cold shock
            dX[:, StateIdx.RESP_RATE] = self.alpha1 * S_cold * 1.5

        else:  # recovery phase
            # HR returns to baseline exponentially
            dX[:, StateIdx.HR] = -k_recovery * 2.0 * (HR - hr_base)

            # HRV rebounds: parasympathetic rebound
            # dHRV/dt = +beta3*(HRV_max - HRV)
            # HRV_max estimated from literature: +80% above baseline
            hrv_max = hrv_base * 1.80
            dX[:, StateIdx.HRV_RMSSD] = self.beta3 * (hrv_max - HRV)

            # PNS rebound (parasympathetic dominance post-cryo)
            dX[:, StateIdx.PNS] = self.beta3 * (1.0 - PNS)
            dX[:, StateIdx.SNS] = -self.beta3 * SNS * 0.5

            # Skin rewarming from core blood flow
            # dT_skin/dt = k2*(core_temp - skin)
            k2 = self.k1 * 0.5
            core = X[:, StateIdx.CORE_TEMP]
            dX[:, StateIdx.SKIN_TEMP] = k2 * (core - SKIN)

            # BP returns to baseline
            bp_base = theta[:, 7]
            dX[:, StateIdx.BP_SYS] = -k_recovery * (X[:, StateIdx.BP_SYS] - bp_base)

        return dX


class HBOTOde(nn.Module):
    """
    Hyperbaric oxygen therapy ODE model.

    Calibrated parameters:
        Source: StatPearls HBOT (2025), PMC (2025), Lund et al. (2003)
        HR decrease: -7.23% over 60 min at 1.3 ATA (PMC 2025)
        HRV HF power increase: +40-60% at 2.5 ATA (Lund 2003)
        SpO2: saturates at 99-100% at 2.4 ATA + 100% O2
    """

    def __init__(self):
        super().__init__()
        self.log_alpha3 = nn.Parameter(torch.tensor(math.log(0.030)))  # O2 HR decrease rate
        self.log_beta4  = nn.Parameter(torch.tensor(math.log(0.008)))  # HRV O2 gain
        self.log_k_spo2 = nn.Parameter(torch.tensor(math.log(0.050)))  # SpO2 saturation rate
        self.log_gamma2 = nn.Parameter(torch.tensor(math.log(0.020)))  # HR mean reversion

    @property
    def alpha3(self): return torch.exp(self.log_alpha3)
    @property
    def beta4(self):  return torch.exp(self.log_beta4)
    @property
    def k_spo2(self): return torch.exp(self.log_k_spo2)
    @property
    def gamma2(self): return torch.exp(self.log_gamma2)

    def forward(
        self,
        X: torch.Tensor,
        U: torch.Tensor,
        theta: torch.Tensor,
        phase: str = 'stable'
    ) -> torch.Tensor:
        dX = torch.zeros_like(X)

        HR      = X[:, StateIdx.HR]
        HRV     = X[:, StateIdx.HRV_RMSSD]
        SPO2    = X[:, StateIdx.SPO2]
        PNS     = X[:, StateIdx.PNS]

        hr_base     = theta[:, 0]
        hrv_base    = theta[:, 1]
        k_recovery  = theta[:, 10]

        pressure    = U[:, InputIdx.PRESSURE_ATA]   # e.g. 2.4 ATA
        o2_frac     = U[:, InputIdx.OXYGEN_FRAC]    # e.g. 1.0 for 100% O2

        # Oxygen stimulus: product of pressure and O2 fraction
        S_o2 = pressure * o2_frac  # max ~3.0 at 3 ATA pure O2

        if phase == 'compression':
            # Compression: transient HR increase from pressure change
            dX[:, StateIdx.HR] = self.alpha3 * 3.0  # brief sympathetic spike
            dX[:, StateIdx.SPO2] = self.k_spo2 * (99.0 - SPO2)

        else:  # stable phase
            # HR: mild bradycardia from vagal activation
            # Literature: -7.23% HR over 60 min at 1.3 ATA
            # At 2.4 ATA: larger effect, ~-10 to -15%
            hr_target = hr_base * (1.0 - 0.05 * (S_o2 - 1.0) / 2.0)
            dX[:, StateIdx.HR] = -self.gamma2 * (HR - hr_target)

            # SpO2: sigmoid saturation toward 100%
            # SpO2(t) → 100 - exp(-k * S_o2)
            spo2_ceiling = 100.0 - torch.exp(-self.k_spo2 * 10.0 * S_o2)
            dX[:, StateIdx.SPO2] = self.k_spo2 * (spo2_ceiling - SPO2)

            # HRV: increases from parasympathetic activation
            # Literature: HF power +40-60% at 2.5 ATA
            # → RMSSD increase ~20-30%
            hrv_target = hrv_base * (1.0 + 0.25 * (S_o2 - 1.0) / 2.0)
            dX[:, StateIdx.HRV_RMSSD] = self.beta4 * (hrv_target - HRV)

            # PNS increase (vagal activation)
            dX[:, StateIdx.PNS] = self.beta4 * (0.8 - PNS)

        return dX


class SaunaODE(nn.Module):
    """
    Sauna (IR + traditional) ODE model.

    Calibrated parameters:
        Source: Laukkanen et al. (2019), AJP-RICU (2025)
        Peak HR: 100-150 bpm at 73°C (traditional); 80-110 bpm (FIR 60°C)
        Core temp rise: +0.8°C traditional; +0.4°C FIR
        Post-session: HR lower than pre-sauna (-5 to -12 bpm)
    """

    def __init__(self):
        super().__init__()
        self.log_alpha6 = nn.Parameter(torch.tensor(math.log(0.80)))   # HR heat gain
        self.log_beta6  = nn.Parameter(torch.tensor(math.log(0.010)))  # hydration compensation
        self.log_k_core = nn.Parameter(torch.tensor(math.log(0.005)))  # core temp rise rate
        self.log_k_skin = nn.Parameter(torch.tensor(math.log(0.015)))  # skin temp rise rate

    @property
    def alpha6(self): return torch.exp(self.log_alpha6)
    @property
    def beta6(self):  return torch.exp(self.log_beta6)
    @property
    def k_core(self): return torch.exp(self.log_k_core)
    @property
    def k_skin(self): return torch.exp(self.log_k_skin)

    def forward(
        self,
        X: torch.Tensor,
        U: torch.Tensor,
        theta: torch.Tensor,
        phase: str = 'active'
    ) -> torch.Tensor:
        dX = torch.zeros_like(X)

        HR      = X[:, StateIdx.HR]
        SKIN    = X[:, StateIdx.SKIN_TEMP]
        CORE    = X[:, StateIdx.CORE_TEMP]

        hr_base     = theta[:, 0]
        temp_base   = theta[:, 3]
        skin_base   = theta[:, 4]
        k_recovery  = theta[:, 10]
        thermal_s   = theta[:, 11]
        fitness     = theta[:, 12]

        ambient     = U[:, InputIdx.AMBIENT_TEMP]   # e.g. 60°C (FIR) or 73°C (trad)

        # Heat stimulus: ambient - core temperature
        S_heat = torch.clamp(ambient - CORE, min=0.0) * thermal_s

        if phase == 'active':
            # HR: cardiac load from heat
            # Literature: HR rises ~0.5-1.0 bpm per 0.1°C core rise
            dX[:, StateIdx.HR] = (
                self.alpha6 * S_heat / 40.0
                - self.beta6 * fitness  # fitter users have better hydration compensation
            )
            # Skin temperature rises toward ambient
            dX[:, StateIdx.SKIN_TEMP] = self.k_skin * (ambient - SKIN) * 0.3

            # Core temperature rises slowly
            # Literature: +0.4°C FIR, +0.8°C traditional over 30-45 min
            dX[:, StateIdx.CORE_TEMP] = self.k_core * S_heat

            # EDA: elevated due to sweating
            dX[:, StateIdx.EDA_TONIC] = self.alpha6 * S_heat * 0.1

            # SNS activation (heat stress)
            dX[:, StateIdx.SNS] = self.alpha6 * S_heat * 0.02

            # Respiration: increases with heat
            dX[:, StateIdx.RESP_RATE] = self.alpha6 * S_heat * 0.05

        else:  # recovery/cooling
            # Post-sauna: parasympathetic rebound (Laukkanen 2019)
            dX[:, StateIdx.HR] = -k_recovery * 1.5 * (HR - (hr_base - 5.0))
            dX[:, StateIdx.PNS] = k_recovery * (0.9 - X[:, StateIdx.PNS])
            dX[:, StateIdx.SKIN_TEMP] = -self.k_skin * (SKIN - skin_base)
            dX[:, StateIdx.CORE_TEMP] = -self.k_core * 2.0 * (CORE - temp_base)

        return dX


class ExerciseODE(nn.Module):
    """
    Exercise ODE model (run, HIIT, lifting).

    Calibrated from standard exercise physiology literature.
    HR(t) = HR_max - (HR_max - HR_rest) * exp(-k_load * t)
    HRV suppressed proportional to exercise intensity.
    """

    def __init__(self):
        super().__init__()
        self.log_k_load     = nn.Parameter(torch.tensor(math.log(0.020)))
        self.log_k_fatigue  = nn.Parameter(torch.tensor(math.log(0.010)))
        self.log_k_recover  = nn.Parameter(torch.tensor(math.log(0.050)))

    @property
    def k_load(self):    return torch.exp(self.log_k_load)
    @property
    def k_fatigue(self): return torch.exp(self.log_k_fatigue)
    @property
    def k_recover(self): return torch.exp(self.log_k_recover)

    def forward(
        self,
        X: torch.Tensor,
        U: torch.Tensor,
        theta: torch.Tensor,
        phase: str = 'active'
    ) -> torch.Tensor:
        dX = torch.zeros_like(X)

        HR      = X[:, StateIdx.HR]
        HRV     = X[:, StateIdx.HRV_RMSSD]

        hr_base     = theta[:, 0]
        hrv_base    = theta[:, 1]
        fitness     = theta[:, 12]
        k_recovery  = theta[:, 10]

        intensity   = U[:, InputIdx.INTENSITY]   # 0–1 (fraction of VO2max)

        # HR_max estimated: 220 - age (simplified; real system uses user age)
        hr_max = 185.0 * (1.0 - 0.1 * (1.0 - fitness))  # fitness adjusts max HR range

        if phase == 'active':
            # Standard exercise HR kinetics
            hr_target = hr_base + (hr_max - hr_base) * intensity
            dX[:, StateIdx.HR] = self.k_load * (hr_target - HR)

            # HRV suppressed exponentially with fatigue
            dX[:, StateIdx.HRV_RMSSD] = -self.k_fatigue * HRV * intensity

            # SNS dominance during exercise
            dX[:, StateIdx.SNS] = self.k_load * intensity * 0.5
            dX[:, StateIdx.PNS] = -self.k_load * intensity * 0.3

            # Temperature rises with exercise
            dX[:, StateIdx.SKIN_TEMP] = intensity * 0.02
            dX[:, StateIdx.CORE_TEMP] = intensity * 0.008

        else:  # recovery
            dX[:, StateIdx.HR] = -k_recovery * 1.5 * (HR - hr_base)
            hrv_target = hrv_base
            dX[:, StateIdx.HRV_RMSSD] = k_recovery * (hrv_target - HRV)
            dX[:, StateIdx.PNS] = k_recovery * (0.8 - X[:, StateIdx.PNS])

        return dX


# ─── ODE Router ──────────────────────────────────────────────────────────────

class PhysiologicalODEPrior(nn.Module):
    """
    Routes to the correct therapy-specific ODE based on therapy type.
    All ODE parameters are jointly trained with the residual network.
    """

    def __init__(self):
        super().__init__()
        self.cryo       = CryotherapyODE()
        self.hbot       = HBOTOde()
        self.sauna      = SaunaODE()
        self.exercise   = ExerciseODE()

    def forward(
        self,
        X: torch.Tensor,        # (batch, STATE_DIM)
        U: torch.Tensor,        # (batch, INPUT_DIM)
        theta: torch.Tensor,    # (batch, theta_dim)
        therapy_type: int,
        phase: str = 'active'
    ) -> torch.Tensor:
        """Returns dX/dt (batch, STATE_DIM)."""

        if therapy_type == TherapyType.CRYO:
            return self.cryo(X, U, theta, phase)
        elif therapy_type == TherapyType.HBOT:
            return self.hbot(X, U, theta, phase)
        elif therapy_type in (TherapyType.SAUNA_IR, TherapyType.SAUNA_TRAD):
            return self.sauna(X, U, theta, phase)
        elif therapy_type in (TherapyType.RUN, TherapyType.HIIT, TherapyType.LIFT):
            return self.exercise(X, U, theta, phase)
        else:
            # Generic: return zero derivatives (passive monitoring)
            return torch.zeros_like(X)


# ─── RK4 Numerical Solver ────────────────────────────────────────────────────

def rk4_step(
    ode: PhysiologicalODEPrior,
    X: torch.Tensor,
    U: torch.Tensor,
    theta: torch.Tensor,
    dt: float,
    therapy_type: int,
    phase: str = 'active'
) -> torch.Tensor:
    """
    Single 4th-order Runge-Kutta integration step.
    Returns X(t + dt).
    """
    k1 = ode(X,             U, theta, therapy_type, phase)
    k2 = ode(X + dt/2 * k1, U, theta, therapy_type, phase)
    k3 = ode(X + dt/2 * k2, U, theta, therapy_type, phase)
    k4 = ode(X + dt     * k3, U, theta, therapy_type, phase)
    return X + (dt / 6.0) * (k1 + 2*k2 + 2*k3 + k4)


def simulate_ode(
    ode: PhysiologicalODEPrior,
    X0: torch.Tensor,           # (batch, STATE_DIM) initial state
    U_seq: torch.Tensor,        # (batch, T, INPUT_DIM) control sequence
    theta: torch.Tensor,        # (batch, theta_dim)
    dt: float,                  # time step in seconds
    therapy_type: int,
    phase_schedule: Optional[list] = None  # list of (t_start, phase) tuples
) -> torch.Tensor:
    """
    Integrate ODE over T timesteps.
    Returns (batch, T, STATE_DIM) trajectory.
    """
    T = U_seq.shape[1]
    X = X0.clone()
    trajectory = [X.unsqueeze(1)]

    for t in range(T - 1):
        # Determine current phase from schedule
        phase = 'active'
        if phase_schedule:
            for t_start, ph in reversed(phase_schedule):
                if t >= t_start:
                    phase = ph
                    break

        U_t = U_seq[:, t, :]
        X = rk4_step(ode, X, U_t, theta, dt, therapy_type, phase)

        # Clamp to physiological bounds (hard safety constraint)
        X = clamp_physiological(X)
        trajectory.append(X.unsqueeze(1))

    return torch.cat(trajectory, dim=1)  # (batch, T, STATE_DIM)


def clamp_physiological(X: torch.Tensor) -> torch.Tensor:
    """
    Hard physiological bounds — must never be violated.
    These are independent of any learned parameters.
    """
    X = X.clone()
    X[:, StateIdx.HR]         = X[:, StateIdx.HR].clamp(20.0, 240.0)
    X[:, StateIdx.HRV_RMSSD]  = X[:, StateIdx.HRV_RMSSD].clamp(0.1, 300.0)
    X[:, StateIdx.HRV_SDNN]   = X[:, StateIdx.HRV_SDNN].clamp(0.1, 400.0)
    X[:, StateIdx.LF_HF]      = X[:, StateIdx.LF_HF].clamp(0.01, 20.0)
    X[:, StateIdx.SPO2]        = X[:, StateIdx.SPO2].clamp(50.0, 100.0)
    X[:, StateIdx.RESP_RATE]   = X[:, StateIdx.RESP_RATE].clamp(4.0, 60.0)
    X[:, StateIdx.SKIN_TEMP]   = X[:, StateIdx.SKIN_TEMP].clamp(-5.0, 45.0)
    X[:, StateIdx.CORE_TEMP]   = X[:, StateIdx.CORE_TEMP].clamp(33.0, 42.0)
    X[:, StateIdx.BP_SYS]      = X[:, StateIdx.BP_SYS].clamp(50.0, 250.0)
    X[:, StateIdx.EDA_TONIC]   = X[:, StateIdx.EDA_TONIC].clamp(0.0, 50.0)
    X[:, StateIdx.EDA_PHASIC]  = X[:, StateIdx.EDA_PHASIC].clamp(-10.0, 20.0)
    X[:, StateIdx.PERFUSION]   = X[:, StateIdx.PERFUSION].clamp(0.0, 20.0)
    X[:, StateIdx.SNS]         = X[:, StateIdx.SNS].clamp(0.0, 1.0)
    X[:, StateIdx.PNS]         = X[:, StateIdx.PNS].clamp(0.0, 1.0)
    return X
